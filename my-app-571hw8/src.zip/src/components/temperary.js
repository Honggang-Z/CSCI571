//  from topnavbar:
    // handleSelectSearchResult() {
    //     // console.log('card clicked!')
    //     // console.log(`/artical?id=${this.props.url}`)
    //     // console.log(this.props.url)
    //     // isGuardian ? () 
    //     const linkUrl = "/search?q="+this.props.keyword
    //     window.location.href="/search?q="+this.props.keyword
    //     return(
    //         <div>
    //             <Nav.Link as={Link} to="/search?q=tesla" />
    //         </div>
    //     )
    // }
    // inside render:
        // this.handleSearchChange('hey')
        // console.log(this.state.results)
        // this.handleResultSelect(this.state.results[0].title)
        // console.log('Selected Result: ' + this.state.selectedResult)